# ✅ tracker/views.py – Full updated view logic for all features
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.db import models
from django.core.paginator import Paginator
from .models import JobApplication, UserProfile, AvailableJob
from .forms import SignUpForm, JobApplicationForm, ThemeForm, AvailableJobForm, EditProfileForm
import datetime
from datetime import date
def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('dashboard')
        messages.error(request, 'Invalid credentials')
    return render(request, 'tracker/login.html')

def register(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Registration successful! Please login.')
            return redirect('login')
    else:
        form = SignUpForm()
    return render(request, 'tracker/register.html', {'form': form})

@login_required
def logout_view(request):
    logout(request)
    return redirect('login')

@login_required
def dashboard(request):
    jobs = JobApplication.objects.filter(user=request.user)
    followups = jobs.filter(follow_up_date__isnull=False).order_by('follow_up_date')
    status_counts = jobs.values('status').annotate(count=models.Count('id'))
    paginator = Paginator(jobs, 10)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    return render(request, 'tracker/dashboard.html', {
        'jobs': jobs,
        'followups': followups,
        'status_counts': {entry['status']: entry['count'] for entry in status_counts},
        'page_obj': page_obj,
    })

@login_required
def add_job(request):
    if request.method == 'POST':
        form = JobApplicationForm(request.POST)
        if form.is_valid():
            job = form.save(commit=False)
            job.user = request.user
            job.save()
            messages.success(request, 'Job application added!')
            return redirect('dashboard')
    else:
        form = JobApplicationForm()
    return render(request, 'tracker/add_job.html', {'form': form})

@login_required
def edit_job(request, job_id):
    job = get_object_or_404(JobApplication, id=job_id, user=request.user)
    if request.method == 'POST':
        form = JobApplicationForm(request.POST, instance=job)
        if form.is_valid():
            form.save()
            messages.success(request, 'Job application updated!')
            return redirect('dashboard')
    else:
        form = JobApplicationForm(instance=job)
    return render(request, 'tracker/edit_job.html', {'form': form})

@login_required
def delete_job(request, job_id):
    job = get_object_or_404(JobApplication, id=job_id, user=request.user)
    job.delete()
    messages.success(request, 'Job application deleted!')
    return redirect('dashboard')

@login_required
def followups_view(request):
    followups = JobApplication.objects.filter(
        user=request.user,
        follow_up_date__isnull=False,
        follow_up_date__gte=date.today()
    ).order_by('follow_up_date')
    
    return render(request, 'tracker/followups.html', {'followups': followups})
@login_required
def toggle_theme(request):
    profile, created = UserProfile.objects.get_or_create(user=request.user)
    profile.dark_mode = not profile.dark_mode
    profile.save()
    return redirect(request.META.get('HTTP_REFERER', 'dashboard'))

@login_required
def profile_view(request):
    return render(request, 'tracker/profile.html')

@login_required
def edit_profile(request):
    if request.method == 'POST':
        form = EditProfileForm(request.POST, instance=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, 'Profile updated!')
            return redirect('profile')
    else:
        form = EditProfileForm(instance=request.user)
    return render(request, 'tracker/edit_profile.html', {'form': form})

@login_required
def job_list_view(request):
    jobs = JobApplication.objects.filter(user=request.user)
    query = request.GET.get('q')
    status_filter = request.GET.get('status')
    if query:
        jobs = jobs.filter(job_title__icontains=query)
    if status_filter:
        jobs = jobs.filter(status=status_filter)
    paginator = Paginator(jobs, 10)
    page_number = request.GET.get('page')
    jobs_page = paginator.get_page(page_number)
    return render(request, 'tracker/job_list.html', {'jobs': jobs_page})

@login_required
def available_jobs_view(request):
    jobs = AvailableJob.objects.all().order_by('-posted_date')
    return render(request, 'tracker/available_jobs.html', {'jobs': jobs})

@login_required
def apply_to_available_job(request, job_id):
    available_job = get_object_or_404(AvailableJob, id=job_id)
    JobApplication.objects.create(
        user=request.user,
        job_title=available_job.job_title,
        company=available_job.company,
        status='Applied',
        applied_date=datetime.date.today()
    )
    messages.success(request, 'Successfully applied to available job!')
    return redirect('dashboard')

@login_required
def admin_dashboard(request):
    if not request.user.is_superuser:
        return redirect('dashboard')
    users = User.objects.all()
    jobs = AvailableJob.objects.all()
    return render(request, 'tracker/admin_dashboard.html', {'users': users, 'jobs': jobs})

@login_required
def manage_available_jobs(request):
    if not request.user.is_superuser:
        return redirect('dashboard')
    if request.method == 'POST':
        form = AvailableJobForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Available job posted successfully.')
            return redirect('manage_available_jobs')
    else:
        form = AvailableJobForm()
    jobs = AvailableJob.objects.all()
    return render(request, 'tracker/manage_available_jobs.html', {'form': form, 'jobs': jobs})
# views.py
@login_required
def delete_available_job(request, job_id):
    if not request.user.is_superuser:
        return redirect('dashboard')
    job = get_object_or_404(AvailableJob, id=job_id)
    job.delete()
    messages.success(request, 'Job deleted.')
    return redirect('manage_available_jobs')
