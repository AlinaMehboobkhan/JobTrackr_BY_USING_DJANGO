from django.contrib import admin
from .models import JobApplication, UserProfile, AvailableJob

@admin.register(JobApplication)
class JobApplicationAdmin(admin.ModelAdmin):
    list_display = ('job_title', 'company', 'status', 'applied_date', 'follow_up_date', 'user')
    list_filter = ('status', 'company', 'applied_date')
    search_fields = ('job_title', 'company', 'notes')

@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ('user', 'dark_mode')

@admin.register(AvailableJob)
class AvailableJobAdmin(admin.ModelAdmin):
    list_display = ('job_title', 'company', 'posted_date')
