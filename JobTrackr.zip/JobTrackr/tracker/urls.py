from django.urls import path
from . import views

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('login/', views.login_view, name='login'),
    path('signup/', views.register, name='signup'),
    path('logout/', views.logout_view, name='logout'),

    path('add/', views.add_job, name='add_job'),
    path('edit/<int:job_id>/', views.edit_job, name='edit_job'),
    path('delete/<int:job_id>/', views.delete_job, name='delete_job'),

    path('followups/', views.followups_view, name='followups'),
    path('theme/', views.toggle_theme, name='theme'),
    path('profile/', views.profile_view, name='profile'),
    path('profile/edit/', views.edit_profile, name='edit_profile'),
    path('jobs/', views.job_list_view, name='job_list'),

    # New available jobs features
    path('available-jobs/', views.available_jobs_view, name='available_jobs'),
    path('apply/<int:job_id>/', views.apply_to_available_job, name='apply_to_available_job'),

    # Admin views
    path('admin-dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('manage-available-jobs/', views.manage_available_jobs, name='manage_available_jobs'),
    path('admin/delete-available-job/<int:job_id>/', views.delete_available_job, name='delete_available_job'),
]
