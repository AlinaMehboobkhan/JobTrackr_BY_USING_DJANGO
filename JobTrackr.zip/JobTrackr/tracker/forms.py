from django import forms
from .models import JobApplication, UserProfile, AvailableJob
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

class JobApplicationForm(forms.ModelForm):
    class Meta:
        model = JobApplication
        fields = ['job_title', 'company', 'status', 'applied_date', 'follow_up_date']
        widgets = {
            'applied_date': forms.DateInput(attrs={
                'placeholder': 'YYYY-MM-DD', 'type': 'date'
            }),
            'follow_up_date': forms.DateInput(attrs={
                'placeholder': 'YYYY-MM-DD', 'type': 'date'
            }),
        }

class SignUpForm(UserCreationForm):
    email = forms.EmailField(required=True)

    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']

class ThemeForm(forms.ModelForm):
    class Meta:
        model = UserProfile
        fields = ['dark_mode']

class AvailableJobForm(forms.ModelForm):
    class Meta:
        model = AvailableJob
        fields = ['job_title', 'company']

class EditProfileForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['username', 'email']
