from django.test import TestCase
from django.contrib.auth.models import User
from django.urls import reverse

class TrackerTest(TestCase):
    def setUp(self):
        User.objects.create_user('test', 't@t.com', '12345')

    def test_login_page(self):
        r = self.client.get(reverse('login'))
        self.assertEqual(r.status_code, 200)

    def test_dashboard_protected(self):
        r = self.client.get(reverse('dashboard'))
        self.assertRedirects(r, '/login/?next=/')
